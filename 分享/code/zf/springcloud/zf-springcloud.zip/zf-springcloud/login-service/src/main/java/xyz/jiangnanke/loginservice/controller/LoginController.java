package xyz.jiangnanke.loginservice.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Auther: zhengfeng
 * @Date: 2018\12\19 0019 15:48
 * @Description:
 */
@RestController
public class LoginController {

    @Value("${server.port}")
    String port;

    @RequestMapping("/login")
    public String home(@RequestParam(value = "name", defaultValue = "jiangnanke") String name) {
        System.out.println(" this is login for name :" + name);
        return "hi " + name + " ,login is success! the port is:" + port;
    }

}
