package xyz.jiangnanke.feignservice.service;

import org.springframework.stereotype.Component;

/**
 * @Auther: zhengfeng
 * @Date: 2018\12\21 0021 13:50
 * @Description:
 */
@Component
public class SchedualLoginServiceHystrix implements SchedualLoginService{

    @Override
    public String loginOne(String name) {
        System.out.println("******************");
        return "sorry " + name + ", you login is failed!";
    }
}
