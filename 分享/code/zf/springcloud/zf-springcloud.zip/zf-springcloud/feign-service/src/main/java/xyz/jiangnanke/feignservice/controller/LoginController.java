package xyz.jiangnanke.feignservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import xyz.jiangnanke.feignservice.service.SchedualLoginService;

/**
 * @Auther: zhengfeng
 * @Date: 2018\12\20 0020 15:52
 * @Description: 对外暴露一个"/login"的API接口，通过上面定义的Feign客户端SchedualLoginService 来消费服务
 */
@RestController
public class LoginController {
    //编译器报错，无视。 因为这个Bean是在程序启动的时候注入的，编译器感知不到，所以报错。
    @Autowired
    SchedualLoginService schedualLoginService;

    @GetMapping(value = "/login")
    public String login(@RequestParam String name) {
        return schedualLoginService.loginOne(name);
    }
}
