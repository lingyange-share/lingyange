package xyz.jiangnanke.configclient.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Auther: zhengfeng
 * @Date: 2019\1\7 0007 17:32
 * @Description: 返回从配置中心读取的name变量的值
 */
@RestController
@RefreshScope
public class LoginController {

    @Value("${name}")
    String name;
    @Value("${democonfigclient.message}")
    String demoMsg;

    @RequestMapping(value = "/login")
    public String login(){
        return name + " say : " + demoMsg;
    }
}
