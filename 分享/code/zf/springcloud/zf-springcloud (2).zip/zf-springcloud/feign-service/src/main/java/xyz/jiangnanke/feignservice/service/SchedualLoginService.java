package xyz.jiangnanke.feignservice.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * @Auther: zhengfeng
 * @Date: 2018\12\20 0020 15:49
 * @Description: 指定调用login-service服务
 */
@FeignClient(value = "login-service", fallback = SchedualLoginServiceHystrix.class)
public interface SchedualLoginService {
    /**
     * 调用login-service服务的login接口请求
     * @param name
     * @return
     */
    @RequestMapping(value = "/login",method = RequestMethod.GET)
    String loginOne(@RequestParam(value = "name") String name);
}
