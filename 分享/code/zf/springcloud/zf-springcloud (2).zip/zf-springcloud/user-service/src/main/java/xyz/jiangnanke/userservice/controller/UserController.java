package xyz.jiangnanke.userservice.controller;

import brave.sampler.Sampler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @Auther: zhengfeng
 * @Date: 2019\1\8 0008 18:28
 * @Description:
 */
@RestController
public class UserController {

    private static final Logger LOG = Logger.getLogger(UserController.class.getName());

    @RequestMapping("/getUser")
    public String getUser(){
        LOG.log(Level.INFO, "hi is being called UserController getUser");
        return "hi this is method getUser";
    }

    @RequestMapping("/showLogin")
    public String info(){
        LOG.log(Level.INFO, "info is being called UserController showLogin");
        return restTemplate.getForObject("http://localhost:8762/info",String.class);
    }

    @Autowired
    private RestTemplate restTemplate;

    @Bean
    public RestTemplate getRestTemplate(){
        return new RestTemplate();
    }

    @Bean
    public Sampler defaultSampler() {
        return Sampler.ALWAYS_SAMPLE;
    }
}
