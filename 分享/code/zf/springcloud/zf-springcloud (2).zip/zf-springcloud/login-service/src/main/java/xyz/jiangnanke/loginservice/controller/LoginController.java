package xyz.jiangnanke.loginservice.controller;

import brave.sampler.Sampler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @Auther: zhengfeng
 * @Date: 2018\12\19 0019 15:48
 * @Description:
 */
@RestController
public class LoginController {
    private static final Logger LOG = Logger.getLogger(LoginController.class.getName());

    @Value("${server.port}")
    String port;

    @RequestMapping("/login")
    public String home(@RequestParam(value = "name", defaultValue = "jiangnanke") String name) {
        System.out.println(" this is login for name :" + name);
        return "hi " + name + " ,login is success! the port is:" + port;
    }

    @Autowired
    private RestTemplate restTemplate;

    @Bean
    public RestTemplate getRestTemplate() {
        return new RestTemplate();
    }
    @Bean
    public Sampler defaultSampler() {
        return Sampler.ALWAYS_SAMPLE;
    }

    @RequestMapping("/sayHello")
    public String callHome() {
        LOG.log(Level.INFO, "calling trace login-service say hello  ");
        return restTemplate.getForObject("http://localhost:10180/getUser", String.class);
    }

    @RequestMapping("/info")
    public String info() {
        LOG.log(Level.INFO, "calling trace service-hi ");
        return "i'm login-service";
    }

}
