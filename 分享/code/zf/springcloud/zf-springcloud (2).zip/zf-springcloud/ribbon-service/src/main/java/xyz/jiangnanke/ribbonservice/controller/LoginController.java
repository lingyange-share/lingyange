package xyz.jiangnanke.ribbonservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import xyz.jiangnanke.ribbonservice.service.LoginService;

/**
 * @Auther: zhengfeng
 * @Date: 2018\12\20 0020 10:20
 * @Description:
 */
@RestController
public class LoginController {
    @Autowired
    LoginService loginService;

    @GetMapping(value = "/login")
    public String login(@RequestParam String name){
        return loginService.login(name);
    }
}
