package xyz.jiangnanke.ribbonservice.service;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

/**
 * @Auther: zhengfeng
 * @Date: 2018\12\20 0020 10:18
 * @Description:
 */
@Service
public class LoginService {

    @Autowired
    RestTemplate restTemplate;

    @HystrixCommand(fallbackMethod = "loginError")
    public String login(String name) {
        return restTemplate.getForObject("http://LOGIN-SERVICE/login?name="+name,String.class);
        // return restTemplate.getForObject("http://localhost:8762/login?name="+name,String.class);
    }

    public String loginError(String name){
        return "hi " + name + ",I am very Sorry, you login is Error!";
    }
}
