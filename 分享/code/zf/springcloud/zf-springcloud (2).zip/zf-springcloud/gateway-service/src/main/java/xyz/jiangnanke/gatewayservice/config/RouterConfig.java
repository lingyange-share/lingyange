package xyz.jiangnanke.gatewayservice.config;

import org.springframework.cloud.gateway.filter.factory.StripPrefixGatewayFilterFactory;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @Auther: zhengfeng
 * @Date: 2019\1\10 0010 14:41
 * @Description:
 */
@Configuration
public class RouterConfig {

    // @Bean
    // public RouteLocator customRouteLocator(RouteLocatorBuilder builder) {
    //     return builder.routes()
    //             //basic proxy
    //             .route(r -> r.path("/baidu")
    //                     .uri("http://baidu.com:80/")
    //             ).build();
    // }
    @Bean
    public RouteLocator customRouteLocator(RouteLocatorBuilder builder) {
        StripPrefixGatewayFilterFactory.Config config = new StripPrefixGatewayFilterFactory.Config();
        config.setParts(1);
        return builder.routes()
                .route("host_route", r -> r.path("/r/**").filters(f -> f.stripPrefix(1)).uri("http://localhost:8764"))
                .route("host_route", r -> r.path("/f/**").filters(f -> f.stripPrefix(1)).uri("http://localhost:8765"))
                .route("host_route", r -> r.path("/l/**").filters(f -> f.stripPrefix(1)).uri("http://localhost:88762"))
                .build();
    }

}
