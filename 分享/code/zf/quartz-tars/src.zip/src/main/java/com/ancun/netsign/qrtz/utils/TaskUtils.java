package com.ancun.netsign.qrtz.utils;

import com.ancun.netsign.vo.QuartzBeanVO;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * @Auther: zhengfeng
 * @Date: 2018\12\27 0027 15:33
 * @Description:
 */
public class TaskUtils {
    public final static Logger log = LoggerFactory.getLogger(TaskUtils.class);


    /**
     * 通过反射调用scheduleJob中定义的方法
     *
     * @param quartzBean
     */
    @SuppressWarnings("unchecked")
    public static void invokMethod(QuartzBeanVO quartzBean) {
        Object object = null;
        Class clazz = null;
        boolean flag = true;
       if (StringUtils.isNotBlank(quartzBean.getJobClassName())) {
            try {
                clazz = Class.forName(quartzBean.getJobClassName());
                object = clazz.newInstance();
            } catch (Exception e) {
                flag = false;
                log.error("未找到任务执行类[{}]",quartzBean.getJobClassName());
                e.printStackTrace();
            }
        }
        if (object == null) {
            flag = false;
            log.error("未找到任务执行类[{}]",quartzBean.getJobClassName());
            return;
        }
        if(flag){
            log.info("任务[{}]启动成功！", quartzBean);
        }else{
            log.info("任务[{}]启动失败！", quartzBean);
        }

    }
}
