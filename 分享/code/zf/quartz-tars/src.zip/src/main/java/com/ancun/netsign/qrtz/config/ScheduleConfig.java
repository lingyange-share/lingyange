package com.ancun.netsign.qrtz.config;

import com.ancun.netsign.qrtz.job.AncunJob;
import com.ancun.netsign.qrtz.listener.QrtzServerListener;
import com.ancun.netsign.qrtz.service.JobService;
import com.ancun.netsign.qrtz.utils.SpringUtils;
import com.ancun.netsign.vo.QuartzBeanVO;
import org.quartz.*;
import org.quartz.impl.StdSchedulerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @Auther: zhengfeng
 * @Date: 2019\1\2 0002 13:16
 * @Description:
 */
@Component
public class ScheduleConfig {
    private static final Logger log = LoggerFactory.getLogger(QrtzServerListener.class);

    // @Value("#{refreshJobTime}")
    private static int refreshJobTime = 5;

    private static SchedulerFactoryBean schedulerFactoryBean = null;

    @Resource
    private  JobService jobService;

    private  Scheduler scheduler;

    public  SchedulerFactoryBean getSchedulerFactoryBean(){
        if (null == schedulerFactoryBean){
            return SpringUtils.getBean(SchedulerFactoryBean.class);
        }
        if(null == schedulerFactoryBean){
            schedulerFactoryBean = new SchedulerFactoryBean();
            schedulerFactoryBean.setAutoStartup(true);
            schedulerFactoryBean.setStartupDelay(5);//延时5秒启动
            // factory.setQuartzProperties(quartzProperties());
            // schedulerFactoryBean.setJobFactory(springJobFactory);
            return schedulerFactoryBean;
        }
        return schedulerFactoryBean;
    }

    public  JobService getJobService(){
        if(null == jobService){
            return SpringUtils.getBean(JobService.class);
        }
        return jobService;
    }

    public  Scheduler getScheduler(){
        if(null == scheduler){
            return getSchedulerFactoryBean().getScheduler();
        }
        return scheduler;
    }

    public  void init(){
        try {
            scheduler =StdSchedulerFactory.getDefaultScheduler();
            scheduler.start();
            log.info("定时任务 开始启动......");
            log.info("每隔[{}]秒，重新运行任务！", refreshJobTime);
            log.info("调度器是【{}】", scheduler);
            // 这里从数据库中获取任务信息数据
            List<QuartzBeanVO> jobList = getJobService().listQuartzBean("");
            log.info("任务列表是：【{}】", jobList);
            for (QuartzBeanVO job : jobList) {
                try {
                    addJob(job);
                } catch (SchedulerException e) {
                    log.error("加入定时任务[{}]失败",job);
                    log.error(e.getMessage());
                    e.printStackTrace();
                }
            }
            log.info("定时任务 开始启动操作结束......");
        }catch (Exception e){
            e.printStackTrace();
            log.error("定时任务启动失败");
            log.error(e.getMessage());
        }
    }


    /**
     * 添加任务
     *
     * @param quartz
     * @throws SchedulerException
     */
    public void addJob(QuartzBeanVO quartz) throws SchedulerException {
        log.info("添加任务：[{}]", quartz);
        if (quartz == null || !JobConstants.JOB_TRIGGER_STATUS_ACQUIRED.equals(quartz.getTriggerState())) {
            return;
        }

        try {
            log.info("添加任务【{}】到调度器[{}]", quartz, scheduler);
            TriggerKey triggerKey = TriggerKey.triggerKey(quartz.getJobName(), quartz.getJobGroup());
            CronTrigger trigger = null;// = (CronTrigger) new ScheduleConfig().getScheduler().getTrigger(triggerKey);
            //获取.class
            Class cls = Class.forName(quartz.getJobClassName());
            cls.newInstance();
            //创建jobdetail
            JobDetail job = JobBuilder.newJob(cls).withIdentity(quartz.getJobName(),
                    quartz.getJobGroup())
                    //设置参数
                    //.usingJobData("aa", "ceshi")
                    //描述
                    .withDescription(quartz.getDescription())
                    .build();
            // 使用cron表达式
            CronScheduleBuilder cronScheduleBuilder = CronScheduleBuilder.cronSchedule(quartz.getCronExpression());
            trigger = TriggerBuilder.newTrigger().withIdentity("trigger" + quartz.getJobName(), quartz.getJobGroup())
                    .startNow()
                    .withSchedule(cronScheduleBuilder)
                    .build();
            //交由Scheduler安排触发
            getScheduler().scheduleJob(job, trigger);
        }catch (Exception e){
            log.error("加入任务[{}]失败：", quartz);
            log.error(e.getMessage());
            e.printStackTrace();
        }
    }
}
