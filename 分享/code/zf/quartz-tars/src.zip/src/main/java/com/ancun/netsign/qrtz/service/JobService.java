package com.ancun.netsign.qrtz.service;

import com.ancun.netsign.vo.QuartzBeanVO;

import java.util.List;

/**
 * @Auther: zhengfeng
 * @Date: 2018\12\25 0025 10:09
 * @Description:
 */
public interface JobService {

    List<QuartzBeanVO> listQuartzBean(String name);
}
