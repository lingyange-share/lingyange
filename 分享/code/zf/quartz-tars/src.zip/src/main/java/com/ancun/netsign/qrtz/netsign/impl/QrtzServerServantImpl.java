package com.ancun.netsign.qrtz.netsign.impl;

import com.alibaba.fastjson.JSON;
import com.ancun.netsign.qrtz.netsign.QrtzServerServant;
import com.ancun.netsign.qrtz.service.JobService;
import com.ancun.netsign.vo.QuartzBeanVO;
import com.qq.tars.common.support.Holder;
import org.quartz.CronScheduleBuilder;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.TriggerKey;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Auther: zhengfeng
 * @Date: 2018\12\24 0024 15:10
 * @Description:
 */
@Service
public class QrtzServerServantImpl implements QrtzServerServant {
    Logger logger = LoggerFactory.getLogger(QrtzServerServantImpl.class);

    // @Autowired
    // @Qualifier("scheduler")
    // private Scheduler scheduler;
    @Autowired
    private JobService jobService;

    @Override
    public int addSchedule(String quartzDto, Holder<String> quartzStr, Holder<String> msg)  {
        logger.info("开始添加任务[{}]", quartzDto);
        // try{
        //     QuartzBeanVO quartz = JSON.parseObject(quartzDto, QuartzBeanVO.class);
        //     if (quartz.getOldJobGroup() != null) {
        //         JobKey key = new JobKey(quartz.getOldJobName(), quartz.getOldJobGroup());
        //         scheduler.deleteJob(key);
        //     }
        //     //获取.class
        //     Class cls = Class.forName(quartz.getJobClassName());
        //     cls.newInstance();
        //     //创建jobdetail
        //     JobDetail job = JobBuilder.newJob(cls).withIdentity(quartz.getJobName(),
        //             quartz.getJobGroup())
        //             //设置参数
        //             //.usingJobData("aa", "ceshi")
        //             //描述
        //             .withDescription(quartz.getDescription())
        //             .build();
        //     // 使用cron表达式
        //     CronScheduleBuilder cronScheduleBuilder = CronScheduleBuilder.cronSchedule(quartz.getCronExpression());
        //     Trigger trigger = TriggerBuilder.newTrigger().withIdentity("trigger" + quartz.getJobName(), quartz.getJobGroup())
        //             .startNow()
        //             .withSchedule(cronScheduleBuilder)
        //             .build();
        //     //交由Scheduler安排触发
        //     scheduler.scheduleJob(job, trigger);
        //     return 0;
        // } catch (Exception e) {
        //     e.printStackTrace();
        //     return 1;
        // }
        return 0;
    }

    @Override
    public int getScheduleList(String quartzDto, Holder<String> quartzStr, Holder<String> msg) {
        logger.info("开始获取任务列表[{}]", quartzDto);
        QuartzBeanVO quartz = JSON.parseObject(quartzDto, QuartzBeanVO.class);
        List<QuartzBeanVO> list = jobService.listQuartzBean(quartz.getJobName());
        return 0;
    }

    @Override
    public int doSchedule(String quartzDto, Holder<String> quartzStr, Holder<String> msg) {
        logger.info("开始运行任务[{}]", quartzDto);
        // try{
        //     QuartzBeanVO quartz = JSON.parseObject(quartzDto, QuartzBeanVO.class);
        //     JobKey key = new JobKey(quartz.getJobName(), quartz.getJobGroup());
        //     scheduler.triggerJob(key);
        //     return 0;
        // } catch (Exception e) {
        //     e.printStackTrace();
        //     return 1;
        // }
        return 0;
    }

    @Override
    public int pauseSchedule(String quartzDto, Holder<String> quartzStr, Holder<String> msg) {
        logger.info("开始暂停任务[{}]", quartzDto);
        // try{
        //     QuartzBeanVO quartz = JSON.parseObject(quartzDto, QuartzBeanVO.class);
        //     JobKey key = new JobKey(quartz.getJobName(), quartz.getJobGroup());
        //     scheduler.pauseJob(key);
        //     return 0;
        // } catch (Exception e){
        //     e.printStackTrace();
        //     return 1;
        // }
        return 0;
    }

    @Override
    public int recoverSchedule(String quartzDto, Holder<String> quartzStr, Holder<String> msg) {
        logger.info("开始从暂停恢复任务运行[{}]", quartzDto);

        // try{
        //     QuartzBeanVO quartz = JSON.parseObject(quartzDto, QuartzBeanVO.class);
        //     JobKey key = new JobKey(quartz.getJobName(), quartz.getJobGroup());
        //     scheduler.resumeJob(key);
        //     return 0;
        // } catch (Exception e){
        //     e.printStackTrace();
        //     return 1;
        // }
        return 0;
    }

    @Override
    public int deleteSchedule(String quartzDto, Holder<String> quartzStr, Holder<String> msg) {
        logger.info("开始删除任务[{}]", quartzDto);

        // try{
        //     QuartzBeanVO quartz = JSON.parseObject(quartzDto, QuartzBeanVO.class);
        //     TriggerKey triggerKey = TriggerKey.triggerKey(quartz.getJobName(), quartz.getJobGroup());
        //     // 停止触发器
        //     scheduler.pauseTrigger(triggerKey);
        //     // 移除触发器
        //     scheduler.unscheduleJob(triggerKey);
        //     // 删除任务
        //     scheduler.deleteJob(JobKey.jobKey(quartz.getJobName(), quartz.getJobGroup()));
        //     return 0;
        // } catch (Exception e){
        //     e.printStackTrace();
        //     return 1;
        // }
        return 0;
    }
}
