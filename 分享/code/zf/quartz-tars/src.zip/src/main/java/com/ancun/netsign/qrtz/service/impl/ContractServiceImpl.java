package com.ancun.netsign.qrtz.service.impl;

import com.ancun.netsign.dao.ContractDao;
import com.ancun.netsign.po.ContractPO;
import com.ancun.netsign.qrtz.service.ContractService;
import com.ancun.netsign.utils.CommonUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Auther: zhengfeng
 * @Date: 2018\12\24 0024 16:08
 * @Description:
 */
@Service
public class ContractServiceImpl implements ContractService {
    Logger logger = LoggerFactory.getLogger(ContractServiceImpl.class);

    @Autowired
    private ContractDao contractDao;

    @Override
    public List<ContractPO> getAllInvalidContract(String tag) {
        logger.info("获取接入者[{}]已失效但状态还没有改掉的合同信息", tag);
        Map paramMap = new HashMap<>();
        paramMap.put("tag", CommonUtils.getSubmeterTag(tag));

        return contractDao.findByParam(paramMap);
    }

    @Override
    public int updateContract(String tag, List<ContractPO> list) {
        logger.info("批量更新接入者[{}]下合同【{}】为已失效", tag, list);
        if(null==list || list.size()<1){
            return 0;
        }
        Map paramMap = new HashMap<>();
        List<Long> contractIdList = new ArrayList<>();
        for(ContractPO contract : list){
            contractIdList.add(contract.getId());
        }
        paramMap.put("contractIdList", CommonUtils.getSubmeterTag(tag));
        paramMap.put("tag", CommonUtils.getSubmeterTag(tag));
        return contractDao.updateAllInvalidContract(paramMap);
    }
}
