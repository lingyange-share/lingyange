package com.ancun.netsign.qrtz.job;

import com.ancun.netsign.dao.PartnerDao;
import com.ancun.netsign.po.PartnerPO;
import com.ancun.netsign.po.PartnerPOExample;
import com.ancun.netsign.qrtz.service.ContractService;
import com.ancun.netsign.qrtz.utils.SpringUtils;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.io.Serializable;
import java.sql.Date;
import java.util.List;

/**
 * @Auther: zhengfeng
 * @Date: 2018\12\25 0025 09:45
 * @Description:
 */
@Component
public class UpdateContractStatusJob implements Job, Serializable {
    Logger logger = LoggerFactory.getLogger(UpdateContractStatusJob.class);

    private static final long serialVersionUID = 1L;

    @Autowired
    private ContractService contractService;
    @Autowired
    private PartnerDao partnerDao;

    public PartnerDao getPartnerDao(){
        if(null == partnerDao){
            partnerDao = SpringUtils.getBean(PartnerDao.class);
        }
        return partnerDao;
    }

    public ContractService getContractService(){
        if(null == contractService){
            contractService = SpringUtils.getBean(ContractService.class);
        }
        return contractService;
    }

    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        logger.info("【{}】：开始执行任务", new Date(System.currentTimeMillis()));
        System.out.println("【{}】：开始执行任务:"+ new Date(System.currentTimeMillis()));
        // 查询全部接入者
        PartnerPOExample partnerPOExample = new PartnerPOExample();
        List<PartnerPO> partnerList = getPartnerDao().selectByExample(partnerPOExample);
        if(null != partnerList && partnerList.size()>0){
            for(PartnerPO partnerPO : partnerList){
                String tag = partnerPO.getPartnerTag();
                List contractList = getContractService().getAllInvalidContract(tag);
                logger.info("处理接入者[{}]下的合同信息【{}】", tag , contractList);
                // contractService.updateContract(tag, contractService.getAllInvalidContract(tag));
            }
        }
        logger.info("【{}】：任务执行成功", new Date(System.currentTimeMillis()));
        System.out.println("【{}】：开始执行成功:"+ new Date(System.currentTimeMillis()));
    }
}

