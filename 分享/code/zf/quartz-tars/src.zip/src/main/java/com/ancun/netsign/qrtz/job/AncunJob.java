package com.ancun.netsign.qrtz.job;

import com.ancun.netsign.qrtz.service.JobService;
import com.ancun.netsign.qrtz.utils.SpringUtils;
import com.ancun.netsign.vo.QuartzBeanVO;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.io.Serializable;
import java.sql.Date;
import java.util.List;

/**
 * @Auther: zhengfeng
 * @Date: 2018\12\27 0027 17:27
 * @Description:
 */
@Component
public class AncunJob implements Job, Serializable {
    Logger logger = LoggerFactory.getLogger(AncunJob.class);

    private static final long serialVersionUID = 1L;

    @Resource
    private JobService jobService;

    public JobService getJobService(){
        if(null == jobService){
            return SpringUtils.getBean(JobService.class);
        }
        return jobService;
    }

    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        logger.info("ancun任务开始：【{}】：开始执行任务", new Date(System.currentTimeMillis()));
        // 查询全部任务
        // todo 执行任务
        List<QuartzBeanVO> jobList = getJobService().listQuartzBean("");
        logger.info("任务列表是：【{}】", jobList);
        logger.info("【{}】：ancun任务执行成功", new Date(System.currentTimeMillis()));
    }


}