package com.ancun.netsign.qrtz.netsign;

import com.qq.tars.common.support.Holder;
import com.qq.tars.protocol.annotation.Servant;
import com.qq.tars.protocol.tars.annotation.TarsHolder;

/**
 * @Auther: zhengfeng
 * @Date: 2018\12\24 0024 15:04
 * @Description:
 */
@Servant
public interface QrtzServerServant {

    /**
     * 添加任务
     * @param quartzDto
     * @param quartzStr
     * @param msg
     * @return
     */
    int addSchedule(String quartzDto, @TarsHolder Holder<String> quartzStr, @TarsHolder Holder<String> msg);

    /**
     * 获取任务列表
     * @param quartzDto
     * @param quartzStr
     * @param msg
     * @return
     */
    int getScheduleList(String quartzDto, @TarsHolder Holder<String> quartzStr, @TarsHolder Holder<String> msg);

    /**
     * 运行任务
     * @param quartzDto
     * @param quartzStr
     * @param msg
     * @return
     */
    int doSchedule(String quartzDto, @TarsHolder Holder<String> quartzStr, @TarsHolder Holder<String> msg);

    /**
     * 暂停任务
     * @param quartzDto
     * @param quartzStr
     * @param msg
     * @return
     */
    int pauseSchedule(String quartzDto, @TarsHolder Holder<String> quartzStr, @TarsHolder Holder<String> msg);

    /**
     * 从暂停中恢复任务运行
     * @param quartzDto
     * @param quartzStr
     * @param msg
     * @return
     */
    int recoverSchedule(String quartzDto, @TarsHolder Holder<String> quartzStr, @TarsHolder Holder<String> msg);

    /**
     * 删除任务
     * @param quartzDto
     * @param quartzStr
     * @param msg
     * @return
     */
    int deleteSchedule(String quartzDto, @TarsHolder Holder<String> quartzStr, @TarsHolder Holder<String> msg);
}
