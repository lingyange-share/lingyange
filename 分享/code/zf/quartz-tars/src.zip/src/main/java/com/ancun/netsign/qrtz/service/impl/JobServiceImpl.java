package com.ancun.netsign.qrtz.service.impl;

import com.ancun.netsign.dao.JobDao;
import com.ancun.netsign.qrtz.service.JobService;
import com.ancun.netsign.vo.QuartzBeanVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Auther: zhengfeng
 * @Date: 2018\12\25 0025 10:10
 * @Description:
 */
@Service
public class JobServiceImpl implements JobService {
    Logger logger = LoggerFactory.getLogger(JobServiceImpl.class);

    @Autowired
    private JobDao jobDao;

    @Override
    public List<QuartzBeanVO> listQuartzBean(String name) {
        logger.info("查询定时任务任务[{}]");
        return jobDao.listQuartzBean(name);
    }
}
