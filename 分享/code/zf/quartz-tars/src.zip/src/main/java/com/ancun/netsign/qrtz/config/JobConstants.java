package com.ancun.netsign.qrtz.config;

/**
 * @Auther: zhengfeng
 * @Date: 2018\12\27 0027 15:39
 * @Description:
 */
public class JobConstants {
    /**
     * 任务状态
     */
    public final static String JOB_TRIGGER_STATUS_ACQUIRED = "ACQUIRED";// 正常
    public final static String JOB_TRIGGER_STATUS_PAUSED = "PAUSED"; //停止
    public final static String JOB_TRIGGER_STATUS_DELETE = "DELETE";//删除

    public static final String CONCURRENT_IS = "1";
    public static final String CONCURRENT_NOT = "0";
}
