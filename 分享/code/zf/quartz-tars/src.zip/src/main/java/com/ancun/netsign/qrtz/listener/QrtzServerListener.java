package com.ancun.netsign.qrtz.listener;

import com.ancun.netsign.database.config.DataSourceConfig;
import com.ancun.netsign.qrtz.config.ScheduleConfig;
import com.ancun.netsign.qrtz.job.AncunJob;
import com.ancun.netsign.qrtz.utils.SpringUtils;
import com.qq.tars.common.util.Config;
import com.qq.tars.server.core.AppContextEvent;
import com.qq.tars.server.core.AppContextListener;
import com.qq.tars.server.core.AppServantEvent;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Import;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * @Auther: zhengfeng
 * @Date: 2018\12\24 0024 15:01
 * @Description:
 */
@Component
@Import({DataSourceConfig.class})
public class QrtzServerListener implements AppContextListener {
    private static final Logger log = LoggerFactory.getLogger(QrtzServerListener.class);

    @Resource
    private ScheduleConfig scheduleConfig;

    public ScheduleConfig getScheduleConfig(){
        if(null == scheduleConfig){
            return SpringUtils.getBean(ScheduleConfig.class);
        }
        return scheduleConfig;
    }

    @Override
    public void appContextStarted(AppContextEvent appContextEvent) {
        log.info("Tars服务 Qrtz-Server 开始启动......");
        getScheduleConfig().init();
    }

    @Override
    public void appServantStarted(AppServantEvent appServantEvent) {
        log.info("Tars 服务启动……");
        // todo 启动定时任务
    }
}
