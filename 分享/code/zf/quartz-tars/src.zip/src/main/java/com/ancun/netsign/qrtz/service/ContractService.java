package com.ancun.netsign.qrtz.service;

import com.ancun.netsign.po.ContractPO;

import java.util.List;

/**
 * @Auther: zhengfeng
 * @Date: 2018\12\24 0024 16:01
 * @Description:
 */
public interface ContractService {

    /**
     * 获取所有时间失效但状态还是未完成的合同
     * @param tag
     * @return
     */
    List<ContractPO>  getAllInvalidContract(String tag);

    /**
     * 修改合同信息：修改合同状态
     * @param tag
     * @param list
     * @return
     */
    int updateContract(String tag, List<ContractPO> list);
}
